//
//  ViewController.swift
//  SimpleApp
//
//  Created by BRUNA GAGLIARDI on 27/11/17.
//  Copyright © 2017 BRUNA GAGLIARDI. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var celsiusTextField: UITextField!
    @IBOutlet weak var fahrenheitLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func convertToFahrenheit(_ sender: Any) {
        let celsius = Double(celsiusTextField.text!)
        let fahrenheit = (9.0 * celsius!) / 5.0 + 32.0
        fahrenheitLabel.text = String(fahrenheit)
        
        
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    
    
}

