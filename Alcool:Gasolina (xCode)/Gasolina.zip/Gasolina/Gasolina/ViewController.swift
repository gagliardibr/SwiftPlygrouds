//
//  ViewController.swift
//  Gasolina
//
//  Created by BRUNA GAGLIARDI on 27/11/17.
//  Copyright © 2017 BRUNA GAGLIARDI. All rights reserved.
//

import UIKit

class ViewController: UIViewController{

    @IBOutlet weak var gasolinaTextField: UITextField!
    @IBOutlet weak var alcoolTextField: UITextField!
    @IBOutlet weak var porcentagemLabel: UILabel!
    @IBOutlet weak var conversorLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func calculaOpcao(_ sender: Any) {
        let gasolina = Double(gasolinaTextField.text!)
        let alcool = Double(alcoolTextField.text!)
        
        if alcool == nil || gasolina == nil || alcool == 0 || gasolina == 0 || alcool! < 0 || gasolina! < 0{
            conversorLabel.text = " Preencha as informações corretamente. "
        } else {
             let calculo = Double (alcool!/gasolina!) * 100
            porcentagemLabel.text = String(format: "%.2f", calculo) + "%"
            
            if calculo < 70 {
                conversorLabel.text = " Abasteça com Alcool! "
            } else{
                conversorLabel.text = " Abasteça com Gasolina! "
       }
        

    }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

