//
//  ViewController.swift
//  Calculadora
//
//  Created by BRUNA GAGLIARDI on 27/11/17.
//  Copyright © 2017 BRUNA GAGLIARDI. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBOutlet weak var visor: UILabel!
    var resultado = String()
    var numeros = Double()
    var conversor = Double()
    var visorResultado: String = "0"
    var operacao = ""
    var op = "%"
    
    var porc = Double()
    func num(operacao: String, numero: String ) {
        if(resultado == operacao || resultado == "0"){
            resultado = numero
            visor.text = resultado
        }else{
            resultado = resultado + numero
            visor.text = resultado
        }
    }



    // Funcoes dos botoes
       
    @IBAction func button(_ sender: UIButton) {
        
        
                /*Funcao para conversao do 1º numero para Double e exibicao na tela
         */
        func oper(operacao: String){
            
            conversor = (resultado as NSString).doubleValue
            numeros = conversor
            resultado = operacao
            visor.text = resultado
        }
        
        // Funcionalides dos botoes
        switch sender.tag {
        case 0:
            //limpar
            numeros = 0
            resultado = "0"
            visor.text = ("\(resultado)")
            
        case 1:
            let plus = "+"
            let minus = "-"
            var temp = String()
            temp = resultado
            var convert = (resultado as NSString).doubleValue
            
            if convert == 0 {
                resultado = minus
                visor.text = resultado
            } else if convert > 0 {
                resultado = minus + temp
                convert = (resultado as NSString).doubleValue
                visor.text = resultado
            } else if convert < 0 {
                convert = convert * (-1)
                resultado = ("\(convert)")
                visor.text = resultado
            }
            
        case 2:
            var convert = (resultado as NSString).doubleValue
            visor.text = "%"
            var porc = (numeros / 100) * convert
            
            resultado = ("\(porc)")
            
        case 3:
            operacao = "/"
            oper(operacao: operacao)
        case 4:
            num(operacao: operacao, numero: "7")
        case 5:
            num(operacao: operacao, numero: "8")
        case 6:
            num(operacao: operacao, numero: "9")
        case 7:
            operacao = "X"
            oper(operacao: operacao)
        case 8:
            num(operacao: operacao, numero: "4")
        case 9:
            num(operacao: operacao, numero: "5")
        case 10:
            num(operacao: operacao, numero: "6")
        case 11:
            operacao = "-"
            oper(operacao: operacao)
        case 12:
            num(operacao: operacao, numero: "1")
        case 13:
            num(operacao: operacao, numero: "2")
        case 14:
            num(operacao: operacao, numero: "3")
        case 15:
            operacao = "+"
            op = operacao
            conversor = (resultado as NSString).doubleValue
            numeros = conversor
            resultado = "+"
            visor.text = resultado
        case 16:
            num(operacao: operacao, numero: "0")
        case 17:
            let dot = "."
            if resultado.range(of: ".") == nil{
                resultado = resultado + dot
            }
            
        case 18:
            if operacao == "+"{
                conversor = (resultado as NSString).doubleValue
                numeros = numeros + conversor
                resultado = ("\(numeros)")
                visor.text = resultado
            } else if operacao == "-" {
                conversor = (resultado as NSString).doubleValue
                numeros = numeros - conversor
                resultado = ("\(numeros)")
                visor.text = resultado
            } else if operacao == "X" {
                if op == "%"{
                    visor.text = resultado
                    
                } else {
                    conversor = (resultado as NSString).doubleValue
                    
                    numeros = numeros * conversor
                    resultado = ("\(numeros)")
                    visor.text = resultado
                }
            } else if operacao == "/" {
                conversor = (resultado as NSString).doubleValue
                numeros = numeros / conversor
                resultado = ("\(numeros)")
                visor.text = resultado
            } else if operacao == "%" {
                
                
            }
        default:
            break
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
