//
//  File.swift
//  tableView
//
//  Created by BRUNA GAGLIARDI on 30/11/17.
//  Copyright © 2017 BRUNA GAGLIARDI. All rights reserved.
//

import Foundation
import UIKit

// contactModel

class Contact {
    var name: String?
    var lastName: String?
    var picture: UIImage?
    var email: String?
    var phoneNumber: Int?
    
    
}
