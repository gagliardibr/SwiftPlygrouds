//
//  GameScene.swift
//  exemplo1
//
//  Created by BRUNA GAGLIARDI on 04/12/17.
//  Copyright © 2017 BRUNA GAGLIARDI. All rights reserved.
//

import SpriteKit

class GameScene: SKScene {
    
    var label:SKLabelNode!
    var previousTime:TimeInterval = 0
    var firstTime = true
    var sprit:SKSpriteNode!
    var atlas:SKTextureAtlas!
    
    
    
    override func didMove(to view: SKView) {
            scaleMode = .aspectFit
            backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            size = CGSize(width: 720, height: 1280)
        
            label = SKLabelNode(text: "oi gnt!")
            addChild(label)
        
            label.fontColor = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
            label.position = CGPoint(x: size.width/2, y: -100)
            label.fontSize = 72
            label.zPosition = 1
        
        let action = SKAction.move(by: CGVector(dx: 0, dy: 60), duration: 1)
        let action2 = SKAction.repeatForever(action)
        label.run(action2)
        
       // let texture = SKTexture.init(imageNamed: "AngelinaJolie")
        //sprit = SKSpriteNode.init(imageNamed: "AngelinaJolie")
        atlas = SKTextureAtlas.init(named: "Sprites")
        sprit = SKSpriteNode.init(texture: atlas.textureNamed("JamesHetfield"))
        addChild(sprit)
        
        sprit.position = label.position
        sprit.size = CGSize(width: 250, height: 250)
        sprit.position = CGPoint(x: size.width/2, y: size.height/2)
        sprit.zPosition = 0
        
        let spritList = [
        atlas.textureNamed("JamesHetfield"),
        atlas.textureNamed("Emma Watson")]
        let spritAction = SKAction.animate(with: spritList, timePerFrame: 0.5)
        sprit.run(SKAction.repeatForever(spritAction))
        
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
           let pos = touch.location(in: self)

            
            
            let touchSprite = SKSpriteNode(texture: atlas.textureNamed("JamesHetfield"))
            addChild(touchSprite)
            touchSprite.position = pos
            touchSprite.zPosition = 2
            
            
            if nodes(at: pos).contains(sprit){
                touchSprite.color = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
                touchSprite.colorBlendFactor = 1
            }
            
            
            let action = SKAction.fadeOut(withDuration: 2)
            touchSprite.run(action, completion: {
                touchSprite.removeFromParent()
            })
            
            
        }
    }
    
    

    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        let deltaTime:CGFloat
        
        if firstTime{
            firstTime = false
            deltaTime = 1/60
        } else {
            deltaTime = CGFloat(currentTime-previousTime)
            
        }
    
        previousTime = currentTime
   
      //  label.position.y += deltaTime*60
        
    }
}
